package com.example.vanne.tradish_alpha;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import static android.R.drawable.checkbox_off_background;
import static android.R.drawable.checkbox_on_background;

/**
 * Created by vanne on 8/10/2017.
 */

public class UnscheduledListView extends ArrayAdapter {

    private ArrayList<RestOrderModel>unscheduledList;
    private Activity context;

    /*This handles the orders in restaurant menu */

    public UnscheduledListView(Activity context, ArrayList<RestOrderModel> unscheduledList){
        super(context, R.layout.unscheduledlist, unscheduledList);
        this.unscheduledList = unscheduledList;
        this.context = context;
    }

    public void updateOrders(ArrayList<RestOrderModel> unscheduledList ){
        this.unscheduledList = unscheduledList;
        //Log.i("updating orders", Integer.toString(RestOrderList.size()));
        notifyDataSetChanged();
        //Log.i("After orders", Integer.toString(RestOrderList.size()));
    }



    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent){
        View r = convertView;
        ViewHolder viewHolder = null;
        if(r == null){
            LayoutInflater layoutInflater = context.getLayoutInflater();
            r = layoutInflater.inflate(R.layout.unscheduledlist, null, true);
            viewHolder = new ViewHolder(r);
            r.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder)r.getTag();
        }

        String address = unscheduledList.get(position).getAddress();
        String[] separated = address.split(",");
        String street = separated[0]; // this will contain street
        String city = separated[1]; // this will contain " they taste good"
        viewHolder.tvw1.setText(unscheduledList.get(position).getOrderIdView());
        viewHolder.tvw2.setText(street + "," + city);

        /*
        if(unscheduledList.get(position).isSelected()){
            viewHolder.ctv1.setCheckMarkDrawable(checkbox_on_background);
            viewHolder.ctv1.setChecked(true);
            viewHolder.ctv1.setText("Selected");
        }else{
            viewHolder.ctv1.setCheckMarkDrawable(checkbox_off_background);
            viewHolder.ctv1.setChecked(false);
            viewHolder.ctv1.setText("Select");
        }
        */

        return r;
    }

    class ViewHolder {
        TextView tvw1; //order Id
        TextView tvw2; //address
        ViewHolder(View view){
            tvw1 = (TextView)view.findViewById(R.id.orderId);
            tvw2 = (TextView)view.findViewById(R.id.address);
        }
    }
}

