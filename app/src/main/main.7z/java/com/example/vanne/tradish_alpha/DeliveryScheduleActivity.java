package com.example.vanne.tradish_alpha;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Geocoder;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.gms.maps.model.LatLng;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static android.content.ContentValues.TAG;

public class DeliveryScheduleActivity extends AppCompatActivity {
    String layoutIs = "map";
    private ArrayList<RestOrderModel> selectedList;
    //private ArrayList<LatLng> latLngs = new ArrayList<LatLng>();
    private ArrayList<RestOrderModel> scheduledList = new ArrayList<RestOrderModel>();
    private ArrayList<RestOrderModel> unscheduledList = new ArrayList<RestOrderModel>();
    private ListView unscheduledView;
    private ListView scheduledView;
    private UnscheduledListView unscheduledListView;
    private ScheduledListView scheduledListView;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.delivery_menu, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

        switch (item.getItemId()) {
            case R.id.settings:
                Log.i("Menu item selected", "Settings");
                return true;
            case R.id.send:
                Log.i("Menu item selected", "Schedule sended to the driver");
                return true;
            default:
                return false;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_schedule);
        selectedList = getIntent().getParcelableArrayListExtra("orderList");
        //unscheduledList = selectedList;

        /*Convert Address into LatLng and populate the unscheduled list*/
        for (int i = 0; i < selectedList.size(); i++) {
            /*populate unscheudled list*/
            unscheduledList.add(selectedList.get(i));
            LatLng latLng = getLocationFromAddress(this, selectedList.get(i).getAddress());
            if(latLng == null){
                Log.i("latlng", "nothing");
            } else {
                selectedList.get(i).setLatLng(latLng);
                //latLngs.add(latLng);
            }
        }



        //Do you need custom array Adpter?
        unscheduledView = (ListView)findViewById(R.id.unscheduled);
        scheduledView = (ListView)findViewById(R.id.scheduled);
        unscheduledListView = new UnscheduledListView(this,unscheduledList);
        unscheduledView.setAdapter(unscheduledListView);
        scheduledListView = new ScheduledListView(this, scheduledList);
        scheduledView.setAdapter(scheduledListView);

        //Handlers for unscheduled list
        unscheduledView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?>parent, View view, int position, long id){
                scheduledList.add(unscheduledList.get(position));
                scheduledList.get(scheduledList.size()-1).setSequence(position);
                unscheduledList.remove(position);
                updateListView();
            }
        });


        unscheduledView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                RestOrderModel target = unscheduledList.get(position);
                String message = target.getOrderIdView() + "\n"
                        + target.getAddress() + "\n"
                        + target.getTotalPriceView() + "\n";
                //Generate an alert
                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(DeliveryScheduleActivity.this);
                alertDialog.setIcon(android.R.drawable.ic_lock_idle_alarm);
                alertDialog.setTitle("Order Details");
                alertDialog.setMessage(message);
                alertDialog.setNeutralButton("Okay", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.i("in no button", Integer.toString(i));
                    }
                });

                alertDialog.show();
                return true;
            }
        });

        scheduledView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?>parent, View view, int position, long id){
                Log.i("in scheduled, pos ", Integer.toString(position));
            }
        });

        scheduledView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                RestOrderModel target = scheduledList.get(position);
                String message = "ID " + target.getOrderIdView() + "\n"
                        + "Address:" + target.getAddress() + "\n"
                        + "Price($): " + target.getTotalPriceView() + "\n";
                //Generate an alert
                final AlertDialog.Builder alertDialog = new AlertDialog.Builder(DeliveryScheduleActivity.this);
                alertDialog.setIcon(android.R.drawable.ic_lock_idle_alarm);
                alertDialog.setTitle("Rescheduling the item");
                alertDialog.setMessage(message);


                alertDialog.setNegativeButton("No, keep it", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.i("in no button", Integer.toString(i));
                    }
                });

                alertDialog.setPositiveButton("Yes, reschedule", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        unscheduledList.add(scheduledList.get(position));
                        unscheduledList.get(unscheduledList.size()-1).setSequence(-1);
                        scheduledList.remove(position);
                        updateListView();
                    }
                });

                alertDialog.setNeutralButton("Update Map", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i){

                        Fragment fragment;
                        //fragment = new DeliveryFragment();
                        Bundle bundle = new Bundle();
                        bundle.putParcelableArrayList("selectedList", scheduledList);
                        fragment = new MapFragment();
                        fragment.setArguments(bundle);
                        FragmentManager fm = getFragmentManager();
                        FragmentTransaction ft = fm.beginTransaction();
                        ft.replace(R.id.MapFragment, fragment);
                        ft.commit();

                    }
                });

                alertDialog.show();
                return true;
            }
        });
    }

    public void updateListView(){
        unscheduledListView.updateOrders(unscheduledList);
        scheduledListView.updateOrders(scheduledList);
    }

    public void changeFragment(View view){
        Fragment fragment;
        //fragment = new DeliveryFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList("selectedList", selectedList);
        //bundle.putParcelableArrayList("latLngs",latLngs);
        Button button = (Button)findViewById(R.id.buttonx);
        if(layoutIs == "map") {
            fragment = new MapFragment();
            button.setText("Close Map");
            layoutIs = "blank";
        } else {
            fragment = new Fragment();
            button.setText("Displace Order On Map");
            layoutIs = "map";
        }


        fragment.setArguments(bundle);
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.MapFragment, fragment);
        ft.commit();
        Log.i("completed", "executed fragment transcation");
    }

    public LatLng getLocationFromAddress(Context context, String strAddress) {
        Log.i("Address", strAddress);

        Geocoder coder = new Geocoder(context);
        Log.i("Geo",Boolean.toString(coder.isPresent()));
        List<android.location.Address> address;
        LatLng p1 = null;

        try {
            // May throw an IOException
            address = coder.getFromLocationName(strAddress, 1);
            if (address == null || address.size() == 0) {
                return null;
            }else {
                Log.i("So it is not null", Integer.toString(address.size()));
                android.location.Address location = address.get(0);
                Log.i("What is it", address.get(0).toString());

                Double lat = location.getLatitude();
                Double lng = location.getLongitude();
                Log.i("LatLng",Double.toString(lat) + Double.toString(lng) );
                p1 = new LatLng(lat, lng);
            }

        } catch (IOException ex) {

            ex.printStackTrace();
        }

        return p1;
    }

}
