package com.example.vanne.tradish_alpha;

import android.app.Activity;

import java.util.ArrayList;

/**
 * Created by vanne on 8/7/2017.
 */

public class DeliveryOrderModel {
    boolean isSelected;
    ArrayList<String> orderIdList;
    ArrayList<Double> totalPriceList;
    ArrayList<String> addressList;
    ArrayList<Integer> orderTypeList;

    /*This handles the orders in delivery order*/
    public DeliveryOrderModel(Activity context, ArrayList<String> orderIdList, ArrayList<Double> totalPriceList,
                               ArrayList<String> addressList, ArrayList<Integer> orderTypeList, boolean isSelected) {

    }

}
