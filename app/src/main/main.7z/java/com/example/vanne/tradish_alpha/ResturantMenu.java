package com.example.vanne.tradish_alpha;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

import static java.util.Arrays.asList;

public class ResturantMenu extends AppCompatActivity {

    ListView myListView;
    String identity;
    /*Generate options of array for resturant owners
        View Orders
        EditMenu
        Check Delivery
        Finance Options
    */
    ArrayList<String> restMenu = new ArrayList<String>(asList("View Orders", "Edit Menu", "Schedule Delivery", "Checkbook"));
    ArrayList<String> description = new ArrayList<String>(asList("Check and modify your order", "Change your menu", "Schedule delivery", "Check money flow"));
    ArrayList<Integer> iconid = new ArrayList<Integer>(asList(R.drawable.order_icon, R.drawable.menu_icon,R.drawable.delivery_icon,R.drawable.finance_icon));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resturant_menu);

        final Intent intent = getIntent();
        identity = intent.getStringExtra("Identity");
        TextView userIdentity = (TextView)findViewById(R.id.userIdentity);
        userIdentity.setText("Log in as: " + identity);


        myListView = (ListView)findViewById(R.id.restMenuEdit);
        UserDefinedListView userDefinedListView = new UserDefinedListView(this, restMenu,description, iconid);
        myListView.setAdapter(userDefinedListView);
        /*
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, restMenu);
        */
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?>parent, View view, int position, long id){
                if(position == 0){
                    int restId = 12345;
                    Intent orderIntent = new Intent(getApplicationContext(), OrderListActivity.class);
                    orderIntent.putExtra("RestId", Integer.toString(restId));
                    startActivity(orderIntent);
                }
                else{
                    Toast.makeText(getApplicationContext(), "The selected option is " + restMenu.get(position), Toast.LENGTH_SHORT).show();
                }
            }
        });



    }

}
