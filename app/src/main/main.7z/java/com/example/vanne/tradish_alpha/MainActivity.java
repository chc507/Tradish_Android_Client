package com.example.vanne.tradish_alpha;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    String identity = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        setContentView(R.layout.activity_main);
    }

    public void navigateToCustomer(View view){
        Log.i("Menu", "custom");
        Intent customIntent = new Intent(getApplicationContext(), CustomerMenu.class);
        startActivity(customIntent);
    }

    public void navigateToResturant(View view){
        identity  = "Resturant";
        Intent resturantIntent = new Intent(getApplicationContext(), ResturantMenu.class);
        resturantIntent.putExtra("Identity", identity);
        startActivity(resturantIntent);
    }

}
