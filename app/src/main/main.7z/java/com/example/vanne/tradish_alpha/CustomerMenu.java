package com.example.vanne.tradish_alpha;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import static java.util.Arrays.asList;

public class CustomerMenu extends AppCompatActivity {


    ListView myListView;
    /*Generate options of array for customers

    */
    ArrayList<String> custMenu = new ArrayList<String>(asList("Make Orders", "Favorites", "Track Delivery", "Order History"));
    ArrayList<String> description = new ArrayList<String>(asList("Order Your Food", "See your favourite food", "Find where you food is", "Check your history"));
    ArrayList<Integer> iconid = new ArrayList<Integer>(asList(R.drawable.food_icon, R.drawable.heart_icon,R.drawable.route_icon,R.drawable.history_icon));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_menu);

        myListView = (ListView)findViewById(R.id.custMenuEdit);
        UserDefinedListView userDefinedListView = new UserDefinedListView(this, custMenu,description, iconid);
        myListView.setAdapter(userDefinedListView);
        /*
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, restMenu);
        */
        myListView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?>parent, View view, int position, long id){
                Toast.makeText(getApplicationContext(), "The selected option is " + custMenu.get(position), Toast.LENGTH_SHORT).show();

            }
        });
    }
    /*
    public void backToMain(View view){
        //navigate to second activity
        Intent mainIntent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(mainIntent);
    }
    */
}